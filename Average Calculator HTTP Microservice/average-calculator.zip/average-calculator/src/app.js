const express = require('express');
const app = express();
const numberController = require('./controllers/numberController');

app.use(express.json());
app.use('/', numberController);

const PORT = process.env.PORT || 9876;
if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

module.exports = app; // Export the app for testing
