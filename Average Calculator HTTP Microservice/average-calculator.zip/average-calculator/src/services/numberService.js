const { fetchNumbers } = require('../utils/numberUtils');
const config = require('../config');

let windowNumbers = [];

const addNumbers = async (type) => {
  const newNumbers = await fetchNumbers(type);
  console.log('New Numbers:', newNumbers);
  const uniqueNewNumbers = newNumbers.filter(num => !windowNumbers.includes(num));
  console.log('Unique New Numbers:', uniqueNewNumbers);

  windowNumbers = [...windowNumbers, ...uniqueNewNumbers].slice(-config.windowSize);
  console.log('Updated Window Numbers:', windowNumbers);
  
  return { windowNumbers, uniqueNewNumbers };
};

const calculateAverage = (numbers) => {
  if (numbers.length === 0) return 0;
  const sum = numbers.reduce((acc, num) => acc + num, 0);
  return sum / numbers.length;
};

module.exports = { addNumbers, calculateAverage, windowNumbers };
