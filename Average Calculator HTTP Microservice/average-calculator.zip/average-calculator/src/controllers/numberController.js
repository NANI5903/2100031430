const express = require('express');
const router = express.Router();
const { addNumbers, calculateAverage, windowNumbers } = require('../services/numberService');

router.get('/numbers/:type', async (req, res) => {
  const { type } = req.params;
  if (!['p', 'f', 'e', 'r'].includes(type)) {
    return res.status(400).json({ error: 'Invalid type parameter' });
  }

  const windowPrevState = [...windowNumbers];
  const { windowNumbers: windowCurrState, uniqueNewNumbers: numbers } = await addNumbers(type);
  const average = calculateAverage(windowCurrState);

  console.log('Window Previous State:', windowPrevState);
  console.log('Window Current State:', windowCurrState);
  console.log('Numbers:', numbers);
  console.log('Average:', average.toFixed(2));

  res.json({
    windowPrevState,
    windowCurrState,
    numbers,
    avg: average.toFixed(2)
  });
});

module.exports = router;
