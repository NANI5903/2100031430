const axios = require('axios');
const config = require('../config');

const fetchNumbers = async (type) => {
  let endpoint;
  switch (type) {
    case 'p':
      endpoint = 'primes';
      break;
    case 'f':
      endpoint = 'fibo';
      break;
    case 'e':
      endpoint = 'even';
      break;
    case 'r':
      endpoint = 'rand';
      break;
    default:
      return [];
  }
  try {
    console.log(`Fetching numbers from ${config.apiUrl}/${endpoint}`);
    const response = await axios.get(`${config.apiUrl}/${endpoint}`, {
      timeout: 500,
      headers: {
        'Authorization': `Bearer ${config.apiToken}` // Include the authorization header
      }
    });
    console.log('Fetched numbers:', response.data.numbers);
    return response.data.numbers;
  } catch (error) {
    console.error('Error fetching numbers:', error.message);
    return [];
  }
};

module.exports = { fetchNumbers };
